﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Timer = System.Windows.Forms.Timer;



namespace WinFormsApp4
{
    public partial class oi : Form
    {

        const int TB = 40;

        const int NC = 0x84, HC = 1, HT = -1, HK = 0x312;
        const int H1 = 1, H2 = 2, H3 = 3, H4 = 4, H5 = 5;
        const int GB = 28, GC = 4, GR = 7, LS = 30, GG = 2, SI = 60;
        const int DB = 3, DR = 5, DP = 10;
        const int ACT_MIN = 5000, ACT_MAX = 25000;

        const int DA_W = 300, DA_H = 200;

        int BW(bt t) => (t == bt.DetectAbsorption) ? (DA_W / 2) : (t == bt.DetectOverload) ? DA_W : ((t == bt.DetectSatHeart) ? DA_W : LS);
        // int BH(bt t) => /*t == bt.DetectAbsorption ||*/ t == bt.DetectOverload ? DA_H : LS;

        int BH(bt t) => (t == bt.DetectSatHeart) || t == bt.DetectOverload ? DA_H : ((t == bt.DetectAbsorption) ? DA_H / 2 : LS);

        readonly List<BoxItem> b = new();
        readonly object bl = new(), cl = new();

        Rectangle gr = new(40, 40, 126, 222);
        bool em, dm, mg, rg;
        int drag = -1;

        Point off, go, rsmp;
        Rectangle rsr;

        readonly Timer ti = new();
        CancellationTokenSource? cs, acs;


        readonly Dictionary<Keys, bool> kd = new();
        readonly List<DC> dbg = new();

        static readonly Random mrnd = new();
        readonly object rndLock = new();
        readonly SemaphoreSlim clickLock = new(1, 1);

        readonly string path =
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "oi-layout.json");



        public enum bt
        {
            None,
            Overload,
            Absorption,
            RockCake,
            RockCakeOrb,
            Weapon,
            Prayer,
            Health,
            SpecialAttack,
            DetectAbsorption,
            DetectOverload,
            InRoom,
            potPrayer,
            barPrayer,
            DetectSatHeart,
            satHeart
        }


        void HKY()
        {
            try
            {
                var h = AT(PointToClient(Cursor.Position));

                CK(Keys.Insert, bt.None, h);

                CK(Keys.Down, bt.Absorption, h);

                CK(Keys.PageDown, bt.RockCakeOrb, h);

                CK(Keys.Left, bt.Weapon, h);
                CK(Keys.Clear, bt.Prayer, h);
                CK(Keys.Right, bt.Health, h);



                CK(Keys.End, bt.satHeart, h);
                CK(Keys.Home, bt.DetectSatHeart, h);

                // CK(Keys.PageUp, bt.DetectAbsorption, h);
                // CK(Keys.Delete, bt.DetectOverload, h);

                CK(Keys.PageUp, bt.potPrayer, h);
                CK(Keys.Delete, bt.barPrayer, h);


                CK(Keys.F6, bt.InRoom, h);


                CK(Keys.NumPad0, bt.None, h);
                CK(Keys.NumPad1, bt.Overload, h);
                CK(Keys.NumPad2, bt.Absorption, h);
                CK(Keys.NumPad3, bt.RockCake, h);
                CK(Keys.NumPad4, bt.Weapon, h);
                CK(Keys.NumPad5, bt.Prayer, h);
                CK(Keys.NumPad6, bt.Health, h);
                CK(Keys.NumPad7, bt.SpecialAttack, h);
                CK(Keys.NumPad8, bt.DetectAbsorption, h);
                CK(Keys.NumPad9, bt.DetectOverload, h);
                CK(Keys.Add, bt.InRoom, h);

            }
            catch { }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);

            RegisterHotKey(Handle, H1, 0, (int)Keys.OemMinus);
            RegisterHotKey(Handle, H2, 0, (int)Keys.Oemplus);
            RegisterHotKey(Handle, H3, 0, (int)Keys.Add);
            RegisterHotKey(Handle, H4, 0, (int)Keys.F1);
            RegisterHotKey(Handle, H5, 0, (int)Keys.F2);
        }


        string SH(bt t) => t switch
        {
            bt.None => "none",
            bt.Overload => "Overload",
            bt.Absorption => "Absorb",
            bt.RockCake => "rockCacke",
            bt.RockCakeOrb => "LocatorOb",
            bt.Weapon => "Weapon",
            bt.Prayer => "Q-Pray",
            bt.Health => "hpBar-Dt",
            bt.SpecialAttack => "SpecAttk",
            bt.DetectAbsorption => "Absorbsion-Dt",
            bt.DetectOverload => "Overload-Dt",
            bt.InRoom => "InRoom-Dt",
            bt.potPrayer => "pPot",
            bt.barPrayer => "PrayBar-Dt",
            bt.DetectSatHeart => "satheart-Dt",
            bt.satHeart => "satheart",
            _ => "?"
        };

        readonly Dictionary<bt, Color> typeColors = new()
        {
            { bt.None, Color.Gray },
            { bt.Overload, ColorTranslator.FromHtml("#080606") },
            { bt.Absorption, ColorTranslator.FromHtml("#4D6068") },
            { bt.RockCake, ColorTranslator.FromHtml("#584E33") },
            { bt.RockCakeOrb, ColorTranslator.FromHtml("#7133ab") },
            { bt.Weapon, ColorTranslator.FromHtml("#95080F") },
            { bt.Prayer, ColorTranslator.FromHtml("#EADB0D") },
            { bt.Health, ColorTranslator.FromHtml("#7f230c") },
            { bt.SpecialAttack, ColorTranslator.FromHtml("#389AB5") },
            { bt.DetectAbsorption,ColorTranslator.FromHtml("#FFFFFF") },
            { bt.DetectOverload, ColorTranslator.FromHtml("#0000C3") },
            { bt.InRoom, ColorTranslator.FromHtml("#F0C247") },
            { bt.potPrayer, ColorTranslator.FromHtml("#19a36d") },
            { bt.barPrayer, ColorTranslator.FromHtml("#36e5a7") },
            { bt.DetectSatHeart, ColorTranslator.FromHtml("#411c2d") },
            { bt.satHeart, ColorTranslator.FromHtml("#5e355d") }


        };

        readonly Dictionary<bt, double> typeColorMargins = new()
        {
            { bt.None, .1 },
            { bt.Overload, .1 },
            { bt.Absorption, .1 },
            { bt.RockCake, .1 },
            { bt.RockCakeOrb, .1 },
            { bt.Weapon, .1 },
            { bt.Prayer, .2 },
            { bt.Health, .1 },
            { bt.SpecialAttack, .1 },
            { bt.DetectAbsorption, .1 },
            { bt.DetectOverload, .1 },
            { bt.InRoom, .1 },
            { bt.potPrayer, .1 },
            { bt.barPrayer, .1 },
            { bt.DetectSatHeart, .01 },
            { bt.satHeart, .1 }

        };

        readonly Dictionary<bt, int> typeRequiredMatchPixels = new()
        {
            { bt.None, 0 },
            { bt.Overload, 100 },
            { bt.Absorption, 3 },
            { bt.RockCake, 5 },
            { bt.RockCakeOrb, 2 },
            { bt.Weapon, 5 },
            { bt.Prayer, 5 },
            { bt.Health, 1 },
            { bt.SpecialAttack, 5 },
            { bt.DetectAbsorption, 20 },
            { bt.DetectOverload, 2 },
            { bt.InRoom, 2 },
            { bt.potPrayer, 1 },
            { bt.barPrayer, 2 },
            { bt.DetectSatHeart, 2 },
            { bt.satHeart, 2 }
        };



        Task? task,
            prayerDetectedTask,
            prayerPotDetectedTask,
            prayerTimedTask,
            healthTask,
            absorptionTask,
            heartTask;

        public void StartAllActionTimers()
        {
            if (acs != null) return;

            acs = new CancellationTokenSource();
            var t = acs.Token;

            prayerDetectedTask = Task.Run(() => PrayerDetectedLoop(t), t);
            prayerPotDetectedTask = Task.Run(() => PrayerPotDetectedLoop(t), t);
            prayerTimedTask = Task.Run(() => PrayerTimedLoop(t), t);
            healthTask = Task.Run(() => HealthLoop(t), t);
            absorptionTask = Task.Run(() => AbsorptionLoop(t), t);
            heartTask = Task.Run(() => hearthLoop(t), t);
        }

        public void StopAllActionTimers()
        {
            try
            {
                acs?.Cancel();

                if (prayerDetectedTask != null && !prayerDetectedTask.IsCompleted)
                    prayerDetectedTask.Wait(200);

                if (heartTask != null && !heartTask.IsCompleted)
                    heartTask.Wait(200);

                if (prayerPotDetectedTask != null && !prayerPotDetectedTask.IsCompleted)
                    prayerPotDetectedTask.Wait(200);

                if (prayerTimedTask != null && !prayerTimedTask.IsCompleted)
                    prayerTimedTask.Wait(200);

                if (healthTask != null && !healthTask.IsCompleted)
                    healthTask.Wait(200);

                if (absorptionTask != null && !absorptionTask.IsCompleted)
                    absorptionTask.Wait(200);

                acs?.Dispose();
            }
            catch { }

            acs = null;
            prayerDetectedTask = null;
            heartTask = null;
            prayerPotDetectedTask = null;
            prayerTimedTask = null;
            healthTask = null;
            absorptionTask = null;
        }



        async Task hearthLoop(CancellationToken t)
        {
            var rnd = new Random();

            while (!t.IsCancellationRequested)
            {
                try
                {
                    if (!DET(bt.DetectSatHeart) && DET(bt.InRoom))
                    {

                        try
                        {
                            await Task.Delay(rnd.Next(157, 410), t);
                        }
                        catch { }


                        var heartt = FBD(bt.satHeart);

                        if (heartt != null)
                        {
                            await clck(BS(heartt), t);
                            await Task.Delay(500, t);
                            continue;
                        }
                    }
                }
                catch { }

                try
                {
                    await Task.Delay(300, t);
                }
                catch { }
            }
        }


        long prayerCooldownUntil = 0;

        async Task PrayerTimedLoop(CancellationToken t)
        {
            var rnd = new Random();

            while (!t.IsCancellationRequested)
            {
                try
                {

                    if (DET(bt.barPrayer)) return;

                    var prayer = FB(bt.Prayer);

                    if (prayer != null)
                    {

                        if (DET(bt.InRoom))
                        {
                            // await dbc(BS(prayer), t);

                            // block detected loop for 3 seconds
                            Interlocked.Exchange(
                                ref prayerCooldownUntil,
                                Environment.TickCount64 + 1500
                            );

                            await clck(BS(prayer), t);

                            try
                            {
                                await Task.Delay(rnd.Next(200, 300), t);
                            }
                            catch { }
                            await clck(BS(prayer), t);

                        }
                    }
                }
                catch { }

                try
                {
                    await Task.Delay(rnd.Next(5000, 15001), t);
                }
                catch { }
            }
        }

        async Task PrayerDetectedLoop(CancellationToken t)
        {
            var rnd = new Random();

            while (!t.IsCancellationRequested)
            {
                try
                {

                    var prayerbarexists = FBDNNNNN(bt.barPrayer);

                    if ( (DET(bt.barPrayer)|| (prayerbarexists != null)) && DET(bt.InRoom))
                        {

                            var prayer = FBDNNNNN(bt.Prayer);
                            if (prayer != null)
                            {
                                await clck(BS(prayer), t);
                                try
                                {
                                    await Task.Delay(1500, t);
                                }
                                catch { }
                            }

                        }
                        else
                        {

                            // check cooldown
                            if (Environment.TickCount64 < Interlocked.Read(ref prayerCooldownUntil))
                            {
                                await Task.Delay(100, t);
                                continue;
                            }

                            var prayer = FBD(bt.Prayer);

                            if (prayer != null)
                            {
                                await clck(BS(prayer), t);
                                try
                                {
                                    await Task.Delay(1500, t);
                                }
                                catch { }
                            
                        }
                    }
                }
                catch { }

            

                try
                {
                    await Task.Delay(500, t);
                }
                catch { }
            }
        }
        async Task PrayerPotDetectedLoop(CancellationToken t)
        {
            var rnd = new Random();

            while (!t.IsCancellationRequested)
            {
                try
                {

                    if (!DET(bt.barPrayer) && DET(bt.InRoom))
                    {

                        try
                        {
                            await Task.Delay(rnd.Next(2457, 9140), t);
                        }
                        catch { }


                        var prayer = FBD(bt.potPrayer);

                        if (prayer != null)
                        {

                            await clck(BS(prayer), t);

                            try
                            {
                                await Task.Delay(1500, t);
                            }
                            catch { }
                        }

                    }




                }
                catch { }

                try
                {
                    await Task.Delay(500, t);
                }
                catch { }
            }
        }


        async Task HealthLoop(CancellationToken t)
        {

            var rnd = new Random();


            while (!t.IsCancellationRequested)
            {
                try
                {
                    if (!DET(bt.DetectOverload) && DET(bt.InRoom))
                    {

                        try
                        {
                            await Task.Delay(rnd.Next(789, 3453), t);
                        }
                        catch { }

                        var overload = FBD(bt.Overload);

                        if (overload != null)
                        {
                            await clck(BS(overload), t);


                            try
                            {
                                await Task.Delay(7000, t);
                            }
                            catch { }

                            continue;
                        }
                        else
                        {
                            //CloseAppSafe();
                            //return;
                        }
                    }


                    if (DET(bt.DetectOverload) && DET(bt.Health) && DET(bt.InRoom))
                    {

                        try
                        {
                            await Task.Delay(rnd.Next(3457, 6140), t);
                        }
                        catch { }


                        var rockCakeOrb = FBD(bt.RockCakeOrb);
                        var rockCake = FBD(bt.RockCake);


                        if (rockCakeOrb != null)
                        {
                            if (DET(bt.DetectOverload))
                            {
                                await clck(BS(rockCakeOrb), t);
                            }

                            try
                            {
                                await Task.Delay(1500, t);
                            }
                            catch { }
                        }
                        else
                        {

                            if (rockCake != null)
                            {
                                if (DET(bt.DetectOverload))
                                {
                                    await clck(BS(rockCake), t);
                                }
                                try
                                {
                                    await Task.Delay(1500, t);
                                }
                                catch { }
                            }

                        }

                    }

                }
                catch { }

                try
                {
                    await Task.Delay(500, t);
                }
                catch { }
            }
        }

        async Task AbsorptionLoop(CancellationToken t)
        {
            var rnd = new Random();


            while (!t.IsCancellationRequested)
            {
                try
                {
                    if (!DET(bt.DetectAbsorption) && DET(bt.InRoom))
                    {

                        try
                        {
                            await Task.Delay(rnd.Next(3457, 6140), t);
                        }
                        catch { }

                        var absorption = FBD(bt.Absorption);

                        if (absorption != null)
                        {
                            await mclck(BS(absorption), t);
                            await Task.Delay(5000, t);
                            continue;
                        }

                    }
                }
                catch { }

                try
                {
                    await Task.Delay(2000, t);
                }
                catch { }
            }
        }







        public oi()
        {


            FormBorderStyle = 0;
            WindowState = FormWindowState.Maximized;
            TopMost = true;
            BackColor = Color.Magenta;
            TransparencyKey = Color.Magenta;
            DoubleBuffered = true;

            EB();
            LL();

            ti.Interval = 10;
            ti.Tick += IT;
            ti.Start();

            StartColorDetection();
            Resize += (_, _) => Invalidate();

            TopMost = true;
        }


        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            StopAllActionTimers();
            StopColorDetection();
            CD();
            SL();

            UnregisterHotKey(Handle, H1);
            UnregisterHotKey(Handle, H2);
            UnregisterHotKey(Handle, H3);
            UnregisterHotKey(Handle, H4);
            UnregisterHotKey(Handle, H5);

            base.OnFormClosed(e);
        }

        int RR(int min, int max)
        {
            lock (rndLock)
                return mrnd.Next(min, max);
        }

        bool ActionsEnabled => acs != null && !acs.IsCancellationRequested;




        void EB()
        {
            if (b.Count == TB) return;

            b.Clear();
            for (int i = 0; i < TB; i++)
                b.Add(new BoxItem { Id = i, Type = bt.None });
        }

        void RS(BoxItem x)
        {
            x.Detected = false;
            x.LastDetectedAt = null;
            x.LastMatchRatio = 0;
            x.LastMatchPixels = 0;
            x.LastTotalPixelsChecked = 0;
        }

        void LL()
        {
            if (File.Exists(path))
            {
                try
                {
                    var d = JsonSerializer.Deserialize<LD>(File.ReadAllText(path));

                    if (d?.Boxes?.Length == TB)
                    {
                        gr = d.GridRect.TR();

                        lock (bl)
                        {
                            for (int i = 0; i < TB; i++)
                            {
                                b[i].Id = d.Boxes[i].Id;
                                b[i].Type = d.Boxes[i].Type;
                                b[i].Bounds = d.Boxes[i].Bounds.TR();

                                if (b[i].Id >= GB)
                                    b[i].Bounds = new Rectangle(
                                        b[i].Bounds.X,
                                        b[i].Bounds.Y,
                                        BW(b[i].Type),
                                        BH(b[i].Type)
                                    );

                                RS(b[i]);
                            }
                        }

                        Invalidate();
                        return;
                    }
                }
                catch { }
            }

            BD();
            SL();
            Invalidate();
        }

        void BD()
        {
            RG();

            lock (bl)
            {
                for (int i = GB; i < TB; i++)
                {
                    b[i].Bounds = new Rectangle(gr.Right + 40, 40 + (i - GB) * 40, LS, LS);
                    b[i].Type = bt.None;
                    RS(b[i]);
                }
            }
        }

        void RG()
        {
            int w = Math.Max(2, (gr.Width - (GC - 1) * GG) / GC);
            int h = Math.Max(2, (gr.Height - (GR - 1) * GG) / GR);

            gr = new Rectangle(
                gr.X,
                gr.Y,
                GC * w + (GC - 1) * GG,
                GR * h + (GR - 1) * GG
            );

            lock (bl)
            {
                for (int i = 0, y = 0; y < GR; y++)
                {
                    for (int x = 0; x < GC; x++, i++)
                    {
                        var t = b[i].Type;

                        b[i].Id = i;
                        b[i].Type = t;
                        b[i].Bounds = new Rectangle(
                            gr.X + x * (w + GG),
                            gr.Y + y * (h + GG),
                            w,
                            h
                        );
                    }
                }
            }
        }

        void SL()
        {
            try
            {
                var d = new LD
                {
                    GridRect = RD.FR(gr),
                    Boxes = new BX[TB]
                };

                lock (bl)
                {
                    for (int i = 0; i < TB; i++)
                    {
                        d.Boxes[i] = new BX
                        {
                            Id = b[i].Id,
                            Type = b[i].Type,
                            Bounds = RD.FR(b[i].Bounds)
                        };
                    }
                }

                File.WriteAllText(
                    path,
                    JsonSerializer.Serialize(d, new JsonSerializerOptions { WriteIndented = true })
                );
            }
            catch { }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            using var fp = new Pen(Color.Red, 2);
            using var gp = new Pen(Color.Yellow, 2);

            e.Graphics.DrawRectangle(fp, 1, 1, ClientSize.Width - 2, ClientSize.Height - 2);
            e.Graphics.DrawRectangle(gp, gr);

            if (dm)
            {
                foreach (var d in dbg)
                {
                    if (d.Image == null) continue;

                    e.Graphics.DrawImage(d.Image, d.Bounds);
                    using var p = new Pen(Color.Red, 2);
                    e.Graphics.DrawRectangle(p, d.Bounds);
                }
            }

            foreach (var x in SS())
            {
                int w = x.Detected ? DB : 1;

                using var p = new Pen(CO(x.Type), w);
                var r = x.Bounds;
                r.Inflate(-(w / 2), -(w / 2));

                e.Graphics.DrawRectangle(p, r);
                e.Graphics.DrawString(
                    //{x.Id}:
                    //{x.LastMatchPixels}px

                    $"{SH(x.Type)} ",
                    Font,
                    Brushes.White,
                    x.Bounds.X + 2,
                    x.Bounds.Y - 5
                );
            }

            e.Graphics.FillRectangle(Brushes.Yellow, RH());
        }

        void IT(object? s, EventArgs e)
        {
            HKY();

            if (!em) return;

            Point m = PointToClient(Cursor.Position);

            if (rg)
            {
                gr = new Rectangle(
                    rsr.X,
                    rsr.Y,
                    Math.Max(20, rsr.Width + m.X - rsmp.X),
                    Math.Max(20, rsr.Height + m.Y - rsmp.Y)
                );

                RG();
                SL();
                Invalidate();
                return;
            }

            if (mg)
            {
                gr = new Rectangle(m.X - go.X, m.Y - go.Y, gr.Width, gr.Height);

                RG();
                SL();
                Invalidate();
                return;
            }

            lock (bl)
            {
                if (drag >= GB)
                {
                    int w = BW(b[drag].Type), h = BH(b[drag].Type);
                    b[drag].Bounds = new Rectangle(m.X - off.X, m.Y - off.Y, w, h);

                    SL();
                    Invalidate();
                    return;
                }
            }

            if (RH().Contains(m))
            {
                rg = true;
                rsmp = m;
                rsr = gr;
                return;
            }

            if (gr.Contains(m))
            {
                mg = true;
                go = new Point(m.X - gr.X, m.Y - gr.Y);
                return;
            }

            lock (bl)
            {
                for (int i = TB - 1; i >= GB; i--)
                {
                    if (!b[i].Bounds.Contains(m)) continue;

                    drag = i;
                    off = new Point(m.X - b[i].Bounds.X, m.Y - b[i].Bounds.Y);
                    return;
                }
            }
        }


        void CK(Keys k, bt t, BoxItem? h)
        {
            bool down = (GetAsyncKeyState(k) & 0x8000) != 0;
            bool wasDown = kd.TryGetValue(k, out var old) && old;

            if (down && !wasDown && h != null)
            {
                lock (bl)
                {
                    foreach (var x in b)
                    {
                        if (x.Id != h.Id) continue;

                        x.Type = t;

                        if (x.Id >= GB)
                            x.Bounds = new Rectangle(x.Bounds.X, x.Bounds.Y, BW(t), BH(t));

                        RS(x);
                        break;
                    }
                }

                SL();
                if (dm) CAP();
                Invalidate();
            }

            kd[k] = down;
        }

        BoxItem? AT(Point p)
        {
            lock (bl)
            {
                for (int i = TB - 1; i >= 0; i--)
                    if (b[i].Bounds.Contains(p))
                        return b[i].Clone();
            }

            return null;
        }

        public void StartColorDetection()
        {
            if (dm || task is { IsCompleted: false }) return;

            cs = new CancellationTokenSource();
            var t = cs.Token;

            task = Task.Run(async () =>
            {
                while (!t.IsCancellationRequested)
                {
                    try { SCAN(); } catch { }

                    try { await Task.Delay(SI, t); } catch { }
                }
            }, t);
        }

        public void StopColorDetection()
        {
            try
            {
                cs?.Cancel();

                if (task != null && !task.IsCompleted)
                    task.Wait(200);

                cs?.Dispose();
                cs = null;
                task = null;
            }
            catch { }
        }

        void TD()
        {
            dm = !dm;

            if (dm)
            {
                StopColorDetection();
                CAP();
            }
            else
            {
                CD();
                StartColorDetection();
            }

            Invalidate();
        }

        void CD()
        {
            foreach (var x in dbg)
                x.Image?.Dispose();

            dbg.Clear();
        }

        void CAP()
        {
            CD();

            var s = GS();
            if (s.Count == 0) return;

            var vs = SystemInformation.VirtualScreen;
            bool v = Visible;

            Hide();
            Application.DoEvents();
            Thread.Sleep(80);

            using var ss = new Bitmap(vs.Width, vs.Height);
            using (var g = Graphics.FromImage(ss))
                g.CopyFromScreen(vs.Left, vs.Top, 0, 0, vs.Size);

            if (v)
            {
                Show();
                TopMost = true;
                BringToFront();
                TopMost = true;
            }

            foreach (var x in s)
            {
                if (x.Type == bt.None || x.DS == Rectangle.Empty) continue;

                var br = x.DS;
                br.Offset(-vs.Left, -vs.Top);

                var cr = Rectangle.Intersect(br, new Rectangle(0, 0, ss.Width, ss.Height));
                if (cr.Width <= 0 || cr.Height <= 0) continue;

                var cp = new Bitmap(Math.Max(1, x.DS.Width), Math.Max(1, x.DS.Height));

                using (var g = Graphics.FromImage(cp))
                {
                    g.Clear(Color.Black);
                    g.DrawImage(
                        ss,
                        new Rectangle(cr.X - br.X, cr.Y - br.Y, cr.Width, cr.Height),
                        cr,
                        GraphicsUnit.Pixel
                    );
                }

                MR(cp, CO(x.Type), CM(x.Type));

                dbg.Add(new DC
                {
                    BoxId = x.Id,
                    Bounds = x.DC,
                    Image = cp
                });
            }
        }

        void MR(Bitmap m, Color e, double cm)
        {
            int t = (int)(255 * cm);

            for (int y = 0; y < m.Height; y++)
                for (int x = 0; x < m.Width; x++)
                    if (PX(m.GetPixel(x, y), e, t))
                        m.SetPixel(x, y, Color.Red);
        }

        void SCAN()
        {
            var s = GS();
            if (s.Count == 0) return;

            var vs = SystemInformation.VirtualScreen;

            using var ss = new Bitmap(vs.Width, vs.Height);
            using (var g = Graphics.FromImage(ss))
                g.CopyFromScreen(vs.Left, vs.Top, 0, 0, vs.Size);

            var rr = new Dictionary<int, DRS>();

            foreach (var x in s)
            {
                if (x.Type == bt.None || x.DS == Rectangle.Empty)
                {
                    rr[x.Id] = new DRS();
                    continue;
                }

                var r = x.DS;
                r.Offset(-vs.Left, -vs.Top);

                var c = Rectangle.Intersect(r, new Rectangle(0, 0, ss.Width, ss.Height));

                rr[x.Id] = c.Width <= 0 || c.Height <= 0
                    ? new DRS()
                    : CB(ss, c, CO(x.Type), CM(x.Type), CP(x.Type));
            }

            bool ch = false;
            var n = DateTime.Now;

            lock (bl)
            {
                foreach (var x in b)
                {
                    if (!rr.TryGetValue(x.Id, out var r)) continue;

                    ch |= x.Detected != r.Detected
                        || x.LastMatchPixels != r.MatchPixels
                        || x.LastTotalPixelsChecked != r.TotalPixelsChecked;

                    x.Detected = r.Detected;
                    x.LastMatchRatio = r.MatchRatio;
                    x.LastMatchPixels = r.MatchPixels;
                    x.LastTotalPixelsChecked = r.TotalPixelsChecked;

                    if (r.Detected)
                        x.LastDetectedAt = n;
                }
            }

            if (ch && !IsDisposed && IsHandleCreated)
            {
                try { BeginInvoke(new Action(Invalidate)); } catch { }
            }
        }

        List<SB> GS()
        {
            if (IsDisposed || !IsHandleCreated) return new();

            if (InvokeRequired)
                return (List<SB>)Invoke(new Func<List<SB>>(GS));

            var r = new List<SB>();

            lock (bl)
            {
                foreach (var x in b)
                {
                    var d = x.Bounds;
                    d.Inflate(-DP, -DP);

                    if (d.Width < 1 || d.Height < 1)
                        d = Rectangle.Empty;

                    r.Add(new SB
                    {
                        Id = x.Id,
                        Type = x.Type,
                        C = x.Bounds,
                        S = RectangleToScreen(x.Bounds),
                        DC = d,
                        DS = d == Rectangle.Empty ? Rectangle.Empty : RectangleToScreen(d)
                    });
                }
            }

            return r;
        }

        DRS CB(Bitmap ss, Rectangle r, Color e, double cm, int req)
        {
            int t = (int)(255 * cm), tot = 0, mat = 0;

            for (int y = r.Top; y < r.Bottom; y++)
            {
                for (int x = r.Left; x < r.Right; x++)
                {
                    tot++;

                    if (PX(ss.GetPixel(x, y), e, t))
                        mat++;
                }
            }

            return new DRS
            {
                Detected = mat >= req,
                MatchRatio = tot == 0 ? 0 : (double)mat / tot,
                MatchPixels = mat,
                TotalPixelsChecked = tot
            };
        }

        bool PX(Color f, Color e, int t) =>
            Math.Abs(f.R - e.R) <= t &&
            Math.Abs(f.G - e.G) <= t &&
            Math.Abs(f.B - e.B) <= t;



        async Task RDelay(Random rnd, CancellationToken t)
        {
            try
            {
                await Task.Delay(rnd.Next(ACT_MIN, ACT_MAX + 1), t);
            }
            catch { }
        }

        async Task dbc(Point p, CancellationToken t)
        {
            await HumanClickAsync(p, 2, t);
        }

        async Task clck(Point p, CancellationToken t)
        {
            await HumanClickAsync(p, 1, t);
        }

        async Task mclck(Point p, CancellationToken t)
        {
            await HumanClickAsync(p, 2, t);
            await PauseAsync(t);

            if (RR(1, 3) == 1)
            {
                await HumanClickAsync(p, 1, t);
                await PauseAsync(t);
            }

            if (RR(1, 3) == 1)
            {
                await HumanClickAsync(p, 1, t);
                await PauseAsync(t);
            }


        }

        async Task PauseAsync(CancellationToken t)
        {
            if (!ActionsEnabled || t.IsCancellationRequested) return;
            await Task.Delay(RR(600, 850), t);
        }

        /*  async Task HumanClickAsync(Point p, int clicks, CancellationToken t)
          {
              if (!ActionsEnabled || t.IsCancellationRequested) return;

              await clickLock.WaitAsync(t);

              try
              {
                  if (!ActionsEnabled || t.IsCancellationRequested) return;

                  await MoveMouseHumanAsync(p, t);

                  for (int i = 0; i < clicks; i++)
                  {
                      if (!ActionsEnabled || t.IsCancellationRequested) return;

                      await Task.Delay(RR(35, 95), t);

                      mouse_event(0x0002, 0, 0, 0, UIntPtr.Zero);
                      await Task.Delay(RR(45, 120), t);
                      mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero);

                      if (i + 1 < clicks)
                          await Task.Delay(RR(180, 260), t);
                  }
              }
              finally
              {
                  clickLock.Release();
              }
          }
          */
        void CloseAppSafe()
        {
            if (IsDisposed) return;

            try
            {
                BeginInvoke(new Action(() =>
                {
                    StopAllActionTimers();
                    Close();
                    Application.Exit();
                }));
            }
            catch { }
        }

        async Task HumanClickAsync(Point p, int clicks, CancellationToken t)
        {
            if (!ActionsEnabled || t.IsCancellationRequested) return;

            await clickLock.WaitAsync(t);

            try
            {
                if (!ActionsEnabled || t.IsCancellationRequested) return;

                Point target = new(
                    p.X + RR(-6, 7),
                    p.Y + RR(-6, 7)
                );

                Rectangle clickArea = new(
                    p.X - 6,
                    p.Y - 6,
                    13,
                    13
                );

                if (!clickArea.Contains(Cursor.Position))
                    await MoveMouseHumanAsync(target, t);

                for (int i = 0; i < clicks; i++)
                {
                    if (!ActionsEnabled || t.IsCancellationRequested) return;

                    await Task.Delay(RR(35, 95), t);

                    mouse_event(0x0002, 0, 0, 0, UIntPtr.Zero);
                    await Task.Delay(RR(45, 120), t);
                    mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero);


                    // 50% chance to nudge cursor
                    if (RR(0, 2) == 0)
                    {
                        Cursor.Position = new Point(
                            Cursor.Position.X + RR(-2, 3),
                            Cursor.Position.Y + RR(-2, 3)
                        );
                    }

                    if (i + 1 < clicks)
                        await Task.Delay(RR(180, 260), t);
                }
            }
            finally
            {
                clickLock.Release();
            }
        }

        async Task MoveMouseHumanAsync(Point target, CancellationToken t)
        {
            if (!ActionsEnabled || t.IsCancellationRequested) return;

            Cursor.Position = target;

            Point start = Cursor.Position;
            int steps = RR(8, 18);

            for (int i = 1; i <= steps; i++)
            {
                if (!ActionsEnabled || t.IsCancellationRequested) return;

                double x = i / (double)steps;
                double ease = x * x * (3 - 2 * x);

                int px = start.X + (int)((target.X - start.X) * ease) + RR(-2, 3);
                int py = start.Y + (int)((target.Y - start.Y) * ease) + RR(-2, 3);

                Cursor.Position = new Point(px, py);
                await Task.Delay(RR(6, 18), t);
            }

            //if (ActionsEnabled && !t.IsCancellationRequested)
            //   Cursor.Position = target;
        }

        BoxItem? FB(bt type)
        {
            lock (bl)
            {
                foreach (var x in b)
                    if (x.Type == type)
                        return x.Clone();
            }

            return null;
        }

        BoxItem? FBD(bt type)
        {
            lock (bl)
            {
                foreach (var x in b)
                    if (x.Type == type && x.Detected)
                        return x.Clone();
            }

            return null;
        }
        BoxItem? FBDNNNNN(bt type)
        {
            lock (bl)
            {
                foreach (var x in b)
                    if (x.Type == type && !x.Detected)
                        return x.Clone();
            }

            return null;
        }

        bool DET(bt type)
        {
            lock (bl)
            {
                foreach (var x in b)
                    if (x.Type == type && x.Detected)
                        return true;
            }

            return false;
        }

        Point BS(BoxItem box)
        {
            var p = new Point(
                box.Bounds.X + box.Bounds.Width / 2,
                box.Bounds.Y + box.Bounds.Height / 2
            );

            if (IsDisposed || !IsHandleCreated)
                return p;

            return InvokeRequired
                ? (Point)Invoke(new Func<Point>(() => PointToScreen(p)))
                : PointToScreen(p);
        }

        List<BoxItem> SS()
        {
            var s = new List<BoxItem>();

            lock (bl)
                foreach (var x in b)
                    s.Add(x.Clone());

            return s;
        }

        Color CO(bt t)
        {
            lock (cl)
                return typeColors.TryGetValue(t, out var c) ? c : Color.Gray;
        }

        double CM(bt t)
        {
            lock (cl)
                return typeColorMargins.TryGetValue(t, out var m) ? m : .2;
        }

        int CP(bt t)
        {
            lock (cl)
                return typeRequiredMatchPixels.TryGetValue(t, out var p) ? p : DR;
        }

        public void SetTypeColor(bt t, int r, int g, int bb)
        {
            lock (cl)
            {
                typeColors[t] = Color.FromArgb(
                    Math.Clamp(r, 0, 255),
                    Math.Clamp(g, 0, 255),
                    Math.Clamp(bb, 0, 255)
                );
            }

            if (dm) CAP();
            Invalidate();
        }

        public void SetTypeColorMargin(bt t, double m)
        {
            lock (cl)
                typeColorMargins[t] = Math.Clamp(m, 0, 1);

            if (dm) CAP();
            Invalidate();
        }

        public void SetTypeRequiredMatchPixels(bt t, int p)
        {
            lock (cl)
                typeRequiredMatchPixels[t] = Math.Max(0, p);

            Invalidate();
        }



        Rectangle RH() => new(gr.Right - 18, gr.Bottom - 18, 18, 18);

        bool PA(Point p)
        {
            var o = new Rectangle(0, 0, ClientSize.Width, ClientSize.Height);
            var i = o;
            i.Inflate(-2, -2);

            if (o.Contains(p) && !i.Contains(p))
                return true;

            var g = gr;
            g.Inflate(2, 2);

            if (g.Contains(p))
                return true;

            lock (bl)
            {
                foreach (var x in b)
                {
                    var h = x.Bounds;
                    h.Inflate(1, 1);

                    if (h.Contains(p))
                        return true;
                }
            }

            return false;
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == HK)
            {
                int id = m.WParam.ToInt32();

                if (id == H1)
                {
                    em = !em;

                    if (!em)
                        SL();

                    mg = rg = false;
                    drag = -1;
                    Invalidate();
                    return;
                }

                if (id == H2 || id == H3)
                {
                    TD();
                    return;
                }

                if (id == H4)
                {
                    StartAllActionTimers();
                    return;
                }

                if (id == H5)
                {
                    StopAllActionTimers();
                    return;
                }
            }

            if (m.Msg == NC)
            {
                var p = PointToClient(Cursor.Position);

                m.Result = !em
                    ? (IntPtr)HT
                    : PA(p)
                        ? (IntPtr)HC
                        : (IntPtr)HT;

                return;
            }

            base.WndProc(ref m);
        }

        public List<BoxItem> GetAllBoxes() => SS();

        public List<BoxItem> GetDetectedBoxes()
        {
            var r = new List<BoxItem>();

            lock (bl)
                foreach (var x in b)
                    if (x.Detected)
                        r.Add(x.Clone());

            return r;
        }

        public List<BoxItem> GetBoxesByType(bt t)
        {
            var r = new List<BoxItem>();

            lock (bl)
                foreach (var x in b)
                    if (x.Type == t)
                        r.Add(x.Clone());

            return r;
        }


        public class BoxItem
        {
            public int Id { get; set; }
            public bt Type { get; set; }
            public Rectangle Bounds { get; set; }
            public bool Detected { get; set; }
            public DateTime? LastDetectedAt { get; set; }
            public double LastMatchRatio { get; set; }
            public int LastMatchPixels { get; set; }
            public int LastTotalPixelsChecked { get; set; }

            public int X => Bounds.X;
            public int Y => Bounds.Y;
            public int Z => Id;
            public int Width => Bounds.Width;
            public int Height => Bounds.Height;

            public BoxItem Clone() => new()
            {
                Id = Id,
                Type = Type,
                Bounds = Bounds,
                Detected = Detected,
                LastDetectedAt = LastDetectedAt,
                LastMatchRatio = LastMatchRatio,
                LastMatchPixels = LastMatchPixels,
                LastTotalPixelsChecked = LastTotalPixelsChecked
            };
        }

        class SB
        {
            public int Id { get; set; }
            public bt Type { get; set; }
            public Rectangle C { get; set; }
            public Rectangle S { get; set; }
            public Rectangle DC { get; set; }
            public Rectangle DS { get; set; }
        }

        class DC
        {
            public int BoxId { get; set; }
            public Rectangle Bounds { get; set; }
            public Bitmap? Image { get; set; }
        }

        class DRS
        {
            public bool Detected { get; set; }
            public double MatchRatio { get; set; }
            public int MatchPixels { get; set; }
            public int TotalPixelsChecked { get; set; }
        }

        class LD
        {
            public RD GridRect { get; set; } = new();
            public BX[]? Boxes { get; set; }
        }

        class BX
        {
            public int Id { get; set; }
            public bt Type { get; set; }
            public RD Bounds { get; set; } = new();
        }

        class RD
        {
            public int X { get; set; }
            public int Y { get; set; }
            public int Width { get; set; }
            public int Height { get; set; }

            public Rectangle TR() => new(X, Y, Width, Height);

            public static RD FR(Rectangle r) => new()
            {
                X = r.X,
                Y = r.Y,
                Width = r.Width,
                Height = r.Height
            };
        }

        [DllImport("user32.dll")]
        static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);

        [DllImport("user32.dll")]
        static extern bool RegisterHotKey(IntPtr hWnd, int id, int fsModifiers, int vk);

        [DllImport("user32.dll")]
        static extern bool UnregisterHotKey(IntPtr hWnd, int id);

        [DllImport("user32.dll")]
        static extern short GetAsyncKeyState(Keys vKey);



        [DllImport("kernel32.dll")]
        static extern bool FreeConsole();


        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {

            FreeConsole();

            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new oi());
        }


    }



}